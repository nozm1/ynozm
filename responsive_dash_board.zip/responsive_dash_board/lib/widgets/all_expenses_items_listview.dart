import 'dart:math';

import 'package:flutter/material.dart';
import 'package:responsive_dash_board/models/all_expenses_item_model.dart';
import 'package:responsive_dash_board/utils/app_images.dart';
import 'package:responsive_dash_board/widgets/all_expenses_item.dart';

class AllExpensesItemsListview extends StatefulWidget {
  AllExpensesItemsListview({super.key});

  @override
  State<AllExpensesItemsListview> createState() =>
      _AllExpensesItemsListviewState();
}

class _AllExpensesItemsListviewState extends State<AllExpensesItemsListview> {
  final items = [
    AllExpensesItemModel(
        image: Assets.assetsImagesBalance,
        title: "Balance",
        date: "April 2022",
        price: r"$20,129"),
    AllExpensesItemModel(
        image: Assets.assetsImagesIncome,
        title: "Income",
        date: "April 2022",
        price: r"$20,129"),
    AllExpensesItemModel(
        image: Assets.assetsImagesExpenses,
        title: "Expenses",
        date: "April 2022",
        price: r"$20,129")
  ];

  int selectIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Row(
        children: items.asMap().entries.map((e) {
      int index = e.key;
      var item = e.value;

      if (index == 1) {
        return Expanded(
          child: GestureDetector(
            onTap: () {
              updateIndex(index);
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: AllExpensesItem(
                itemModel: item,
                isSelected: selectIndex == index,
              ),
            ),
          ),
        );
      } else {
        return Expanded(
            child: GestureDetector(
          onTap: () {
            updateIndex(index);
          },
          child: AllExpensesItem(
            itemModel: item,
            isSelected: selectIndex == index,
          ),
        ));
      }
    }).toList());
  }

  void updateIndex(int index) {
    setState(() {
      selectIndex = index;
    });
  }
}
