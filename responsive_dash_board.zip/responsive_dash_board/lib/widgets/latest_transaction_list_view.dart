import 'dart:math';

import 'package:flutter/material.dart';
import 'package:responsive_dash_board/models/user_info_model.dart';
import 'package:responsive_dash_board/utils/app_images.dart';
import 'package:responsive_dash_board/widgets/user_info_list_tile.dart';

class LatestTransactionListView extends StatelessWidget {
  const LatestTransactionListView({super.key});

  static const items = [
    UserInfoModel(
        image: Assets.assetsImagesAvatar,
        title: 'madrandi andi',
        subtitle: 'madraniadi20@gmal'),
    UserInfoModel(
        image: Assets.assetsImagesAvatar2,
        title: 'madrandi andi',
        subtitle: 'madraniadi20@gmal'),
    UserInfoModel(
        image: Assets.assetsImagesAvatar3,
        title: 'madrandi andi',
        subtitle: 'madraniadi20@gmal')
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: items.map((e) => IntrinsicWidth(child: UserInfoListTile(userInfoModel: e))).toList(),
      ),
    );

    // SizedBox(
    //   height: 80,
    //   child: ListView.builder(
    //     itemBuilder: (context, index) {
    //       return IntrinsicWidth(
    //           child: UserInfoListTile(userInfoModel: items[index]));
    //     },
    //     itemCount: items.length,
    //     scrollDirection: Axis.horizontal,
    //   ),
    // );
  }
}
