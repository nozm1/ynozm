import 'package:flutter/material.dart';
import 'package:responsive_dash_board/utils/app_styles.dart';

class CustomButton extends StatelessWidget {
  const CustomButton({super.key, this.backgroundcolor, this.textcolor});
  final Color? backgroundcolor , textcolor;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 62,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            backgroundColor: backgroundcolor ?? Color(0xff4db7f2),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 0),
             onPressed: () {},
            child: Text('Send Money',style: AppStyles.styleSemiBold16.copyWith(color: textcolor),),
      ),
    );
  }
}
