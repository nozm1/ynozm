import 'package:flutter/material.dart';
import 'package:responsive_dash_board/models/item_details_model.dart';
import 'package:responsive_dash_board/widgets/income_chart.dart';
import 'package:responsive_dash_board/widgets/item_details.dart';

class IncomeDetails extends StatelessWidget {
  const IncomeDetails({super.key});

  static const items = [
    ItemDetailsModel(
        color: Color(0xff208BC7), title: 'design service', value: '%40'),
    ItemDetailsModel(
        color: Color(0XFF4DB7F2), title: 'design product', value: '%25'),
    ItemDetailsModel(
        color: Color(0xff064060), title: 'product royality', value: '%20'),
    ItemDetailsModel(color: Color(0xffe2decd), title: 'other', value: '%22'),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: items.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return ItemDetails(itemDetailsModel: items[index]);
        });
  }
}
