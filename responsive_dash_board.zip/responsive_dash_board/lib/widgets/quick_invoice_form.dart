import 'package:flutter/material.dart';
import 'package:responsive_dash_board/widgets/custom_button.dart';
import 'package:responsive_dash_board/widgets/title_text_field.dart';

class QuickInvoiceForm extends StatelessWidget {
  const QuickInvoiceForm({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Row(
          children: [
            Expanded(child: TitleTextField(hint: 'type customer name', title: 'Customer Name')),
            SizedBox(
              width: 16,
            ),
            Expanded(child: TitleTextField(hint: 'type email name', title: 'Email Name'))
          ],
        ),
        SizedBox(
          height: 24,
        ),
        Row(
          children: [
            Expanded(child: TitleTextField(hint: 'type item name', title: 'Item Name')),
            SizedBox(
              width: 16,
            ),
            Expanded(child: TitleTextField(hint: 'USD', title: 'Item Mount'))
          ],
        ),
        SizedBox(height: 24,),
        Row(
          children: [
            Expanded(child: CustomButton(backgroundcolor: Colors.transparent,textcolor: Color(0xff4db7f2),)),
            SizedBox(width: 24,),
            Expanded(child: CustomButton(textcolor: Colors.white,))
          ],
        )
      ],
    );
  }
}
