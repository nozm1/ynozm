import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AllExpensesItemHeader extends StatelessWidget {
  const AllExpensesItemHeader({super.key, required this.image,  this.imageBackground,  this.imageColor});
  final String image;
  final Color? imageBackground, imageColor;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          height: 60,
          width: 60,
          decoration:  ShapeDecoration(
              shape: OvalBorder(), color:imageBackground?? Color(0xfffafafa)),
          child: Center(child: SvgPicture.asset(image,colorFilter: ColorFilter.mode(imageColor ?? Color(0xff4eb7f2), BlendMode.srcIn),)),
        ),
        Spacer(),
        Transform.rotate(
            angle: -1.57079633 * 2,
            child: Icon(
              Icons.arrow_back_ios_new_outlined,
              color:imageColor==null? Color(0xff064061):Colors.white,
            ))
      ],
    );
  }
}
