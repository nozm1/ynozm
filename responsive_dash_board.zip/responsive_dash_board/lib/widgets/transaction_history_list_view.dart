import 'package:flutter/material.dart';
import 'package:responsive_dash_board/models/transaction_model.dart';
import 'package:responsive_dash_board/widgets/transaction_item.dart';

class TransactionHistoryListView extends StatelessWidget {
  const TransactionHistoryListView({super.key});
  static const items = [
    TransactionModel(
        title: 'cash withdrawal',
        date: '13 april 2022',
        amount: r'%20,129',
        isWithdarwal: true),
    TransactionModel(
        title: 'landing page project',
        date: '13 april 2022',
        amount: r'%20,129',
        isWithdarwal: false),
    TransactionModel(
        title: 'juni mobile app project',
        date: '13 april 2022',
        amount: r'%20,129',
        isWithdarwal: false)
  ];
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: items.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return TransactionItem(transactionModel: items[index]);
        });
  }
}
